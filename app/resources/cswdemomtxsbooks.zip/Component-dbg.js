sap.ui.define(["sap/fe/core/AppComponent"], function (Component) {
  "use strict";

  return Component.extend("csw.demo.mtxs.books.Component", {
    metadata: {
      manifest: "json",
    },
  });
});
